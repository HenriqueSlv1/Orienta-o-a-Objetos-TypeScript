export interface IList<T> {
    add(item: T): void;
    remove(index: number): void;
    get(index: number): void;
    set(index: number, item: T): void;
    contains(item: T): boolean;
    size(): number;
    isEmpty(): boolean;
    }
    