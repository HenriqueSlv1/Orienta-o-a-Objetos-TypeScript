import { IList } from "./iList";

export interface IStack<T> {
    push(item: T): void;
    pop(item: T): void;
    size(): number;
    isFull(): boolean;
    }
    