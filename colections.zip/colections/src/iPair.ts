

export interface IPair<T,E> {
    left(): T;
    right(): E;
    }