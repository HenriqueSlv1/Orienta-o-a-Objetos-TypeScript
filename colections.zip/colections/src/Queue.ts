import { Lista } from "./Lista";
import { IList } from "./iList";
import { IQueue } from "./iQueue";


export class Queue<T> implements IQueue<T>{
    lista: Array<T>

    constructor() {
        this.lista = []
    }

    enqueue(item: T): void {
        this.lista.unshift(item)
    }

    dequeue(item: T): T {
        return this.lista.shift()
    }

    size(): number {
        console.log('tamanho da fila é de ' + this.isFull.length)
        return this.lista.length
    }

    isFull(): boolean {
        return this.lista.length == 0
    }

    remove(index:number): void{
        this.lista.shift()
    }

}