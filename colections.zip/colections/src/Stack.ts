import { IStack } from "./istack";
import {Lista} from './Lista'

class Stack<T> implements IStack<T>{
    lista: Array<T>

    constructor(){
       this.lista = []
    }

    push(item: T): void {
        this.lista.push(item)
    }

    pop(item: T): void {
        this.lista.pop()
    }

    size(): number {
        console.log("O tamanho da lista " + this.lista.length)
        return this.lista.length
    }

    isFull(): boolean {
        if(this.lista.length > 10){
            console.log('A lista está cheia')
        }
        return 
    }
}