import { IList } from './iList';
export class Lista<T> implements IList<T> {
	lista: Array<T>;
	constructor() {
		this.lista = [];
	}
	add(item: T): void {
		this.lista.push(item);
	}
	remove(index: number): void {
		this.lista.splice(index);
	}
	get(index: number): T {
		return this.lista[index];
	}
	set(index: number, item: T): void {
		this.lista[index] = item;
	}
	contains(item: T): boolean {
		return this.lista.includes(item) 
	}
	size(): number {
		console.log('Tamanho do Array ' + this.lista.length);
		return this.lista.length;
	}
	isEmpty(): boolean {
		return this.lista.length == 0 
}
}