import { IPair } from "./iPair";

 export class Pair <T,E> implements IPair<T,E>{
    _direita: E;
    _esquerda: T;

    constructor(_esquerda: T, _direita: E){
        this._direita = _direita
        this._esquerda = _esquerda
    }
    left(): T {
        return this._esquerda
    }

    right(): E {
        return this._direita
    }
}