
export interface IQueue<T>  {
    enqueue(item: T): void;
    dequeue(item: T): void;
    size(): number;
    isFull(): boolean;
    }