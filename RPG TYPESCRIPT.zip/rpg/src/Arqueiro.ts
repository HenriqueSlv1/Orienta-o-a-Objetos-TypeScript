import { Coisa } from "./Coisa"
import { Personagem } from "./personagem"

export class Arqueiro extends Personagem {
    longRange: number

    constructor() {
        super()
        this.longRange = 20
    }

    longoAlcance(dano: number, vitima: Personagem, distanciaArq: number) {
        if (distanciaArq < this.longRange && distanciaArq >= 0) {
            this.machucar(dano, vitima)
        }
    }
}
