import {Guerrreiro} from "./guerreiro"
import {Arqueiro} from "./arqueiro"
import{ Personagem } from "./personagem"
import { Guildas } from "./Guildas"
import {Coisa} from "./Coisa"

//////PERSONAGENS//////
let  personagem1:Personagem = new Guerrreiro()
let personagem2:Personagem = new Arqueiro()
let personagem3:Personagem = new Guerrreiro()

//////GUILDAS//////
let guilda1:Guildas = new Guildas("Batutinhas")

//////COISAS//////
let coisa1 : Coisa = new Coisa('arvore',1000)

//////TESTES//////
personagem2.machucar(10,personagem1)
personagem1.machucar(20,personagem2)
personagem2.machucar(20,personagem3)
personagem1.curar(personagem2,10,)

console.log(personagem1)
console.log(personagem2)

console.log(personagem1)
console.log(guilda1)

guilda1.adicionarMembro(personagem1)
guilda1.adicionarMembro(personagem2)

personagem1.machucar(50,coisa1)

guilda1.mostraIntegrantes()

console.log(personagem3)










