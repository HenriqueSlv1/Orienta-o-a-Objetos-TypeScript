 import { Coisa } from "./Coisa"
import{ Personagem } from "./personagem"
 
 export class Guerrreiro extends Personagem{
    meleeRange: number

    constructor(){
        super()
        this.meleeRange = 2

    }

    corpoACorpo(dano:number, vitima:Personagem, distancia:number){
        if(distancia < this.meleeRange && distancia >= 0){
            this.machucar(dano,vitima)
        }
    }
}
