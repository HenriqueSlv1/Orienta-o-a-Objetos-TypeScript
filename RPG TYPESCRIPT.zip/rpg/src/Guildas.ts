import { Personagem } from "./personagem"
import { Coisa } from "./Coisa"


export class Guildas extends Personagem {
    nomeGuilda: string
    integrantes: Array<Personagem>
    constructor(nomeGuilda: string, integrantes: Array<Personagem> = []) {
        super()
        this.nomeGuilda = nomeGuilda
        this.integrantes = integrantes
    }
    adicionarMembro( personagem: Personagem) { // criar metodos distintos para add e remove
           console.log("ADD")
            this.integrantes.push(personagem)
    
        }
        removerMmebro(personagem:Personagem){
            console.log("remove")
            let indice: number = this.integrantes.indexOf(personagem)
            this.integrantes.splice(indice,1)
        }

    mostraIntegrantes() {
        console.log("Listar integrantes")
        for (let int of this.integrantes) { // usar nomes referentes ao contexto 
            console.log(int.nome)
        }
    }
}