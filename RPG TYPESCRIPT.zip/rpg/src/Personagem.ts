import { Guildas } from "./Guildas"
import { Coisa } from "./Coisa"

export abstract class Personagem extends Coisa {
    vida: number
    nivel: number
    vivo: boolean
    guilda: Array<Guildas> = []
    constructor() {
        super("a", 1000)
        this.nivel = 1
        this.vivo = true
        this.guilda = this.guilda

    }
    machucar
        (dano: number, vitima: Coisa) {
        if (vitima instanceof Personagem) {
            this.atacarCharacter(dano, vitima)
        } else if (vitima instanceof Coisa) {
            this.atacarThing(dano, vitima)
        }
    }
    atacarCharacter
        (dano: number, vitima: Personagem) {

        if (vitima === this && vitima.guilda == this.guilda) {
            console.log("na1 pode atacar ")
        }
        else if (dano >= vitima.life) {
            vitima.vivo = false
        }
        else if (vitima.nivel > this.nivel + 5) {
            vitima.life -= dano + (dano * 0.5);
            console.log("Aumento de dano aplicada,  50% " + dano + dano * 0.5)
        }
        else if (vitima.nivel < this.nivel - 5) {
            vitima.life -= dano - (dano * 0.5)
            console.log("Reducao de dano aplicada,  50% " + dano * 0.5)
        }
        vitima.life = vitima.life - dano
        console.log("vida da vitima " + vitima.life)
    }

    atacarThing
        (dano: number, coisa: Coisa) {
        console.log("Atque a coisa")
        coisa.life -= dano
        console.log("LIFE da COisa " + coisa.life)

    }

    curar
        (cured: Personagem, cura: number) {
        if (cured instanceof Personagem) {
            this.healCharacters(cura, cured)
        }
    }

    healCharacters
        (cura: number, cured: Personagem) {
        if (cured != this) {
            cura == 0
            return

        } else if (cured.life == 0) {
            cura = 0
            return

        } else if (cured.life >= 1000 && cura > 0) {
            cured.life = 1000

        } else if (cured.life >= 0 && cura < cured.life) {
            cured.life = cured.life + cura

        } else if (cured.guilda == cured.guilda) {
            cura = cura
        }

    }

    equals(coisa: Coisa): boolean {
        return this.nome === coisa.nome
    }

}

