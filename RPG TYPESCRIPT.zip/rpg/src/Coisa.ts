
export class Coisa {
    nome: string
    life: number
    destroyed: boolean
    constructor(nome: string, life: number) {
        this.nome = nome
        this.life = life
        this.destroyed = false
    }
    destroy() {

        this.life = 0
        this.destroyed = false

    }
}